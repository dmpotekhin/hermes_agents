---
name: github-pages-booknotes
description: Manage book notes on dmpotekhin.github.io — add structured summaries (theses + takeaway) from Excel data, update rendering, deploy.
---

# GitHub Pages Book Notes Workflow

## Site Structure
- Repo: `/Users/dmitrypotekhin/Downloads/dmpotekhin.github.io`
- Remote: `git@github.com:dmpotekhin/dmpotekhin.github.io.git` (branch: `master`)
- Key files:
  - `books.html` — book collection page with genre filters, search, sort
  - `js/books-data.js` — `const booksData = [{...}, ...]` — 521 books with `id, title, author, year, genre, tags`
  - `js/notes-data.js` — `const bookNotes = { "Название": { theses: [...], takeaway: "..." } }` — notes keyed by exact `title`
  - `js/books.js` — rendering: creates `.book-notes-btn` for books with notes, expandable panel
  - `css/styles.css` — `.book-notes-btn`, `.book-notes-panel`, `.book-notes-theses`, `.book-notes-takeaway`

## Notes Format (mandatory)
```javascript
"Точное Название Книги": {
  "theses": [
    "1. Главный герой и его задача/проблема.",
    "2. Где и когда происходит действие.",
    "3. Главный конфликт или движущая сила сюжета.",
    "4. Ключевой поворот или неожиданный элемент.",
    "5. Чем заканчивается (без спойлеров)."
  ],
  "takeaway": "2-3 предложения: о чём книга на самом деле, чему учит. Для нон-фикшн — практическая польза."
}
```

## Adding Notes — Step by Step

1. **Identify target books**: extract books without notes using:
   ```bash
   cd /Users/dmitrypotekhin/Downloads/dmpotekhin.github.io
   node -e "const a=JSON.parse(require('fs').readFileSync('js/books-data.js','utf8').match(/\[[\s\S]*\]/)[0]);const bn=eval('('+require('fs').readFileSync('js/notes-data.js','utf8').match(/const bookNotes = ([\s\S]*);/)[1]+')');console.log(a.filter(b=>!bn[b.title]).length)"
   ```

2. **Generate notes**: use web search for summaries (Путь А), then write structured theses + takeaway. Append to `js/notes-data.js` by inserting new entries before the closing `};`.

3. **Update rendering** if format changes: edit `js/books.js` `createBookCard()` function — the notes panel opening logic.

4. **Update CSS** if UI changes: `.book-notes-theses`, `.book-notes-takeaway` styles.

5. **Verify locally**:
   ```bash
   cd /Users/dmitrypotekhin/Downloads/dmpotekhin.github.io
   python3 -m http.server 8765 &
   # Open http://localhost:8765/books.html in browser
   ```

6. **Commit and push**:
   ```bash
   git add js/notes-data.js js/books.js css/styles.css books.html
   git commit -m "feat: N book notes"
   git push origin master
   ```

7. **User refreshes** with Cmd+Shift+R at https://dmpotekhin.github.io/books.html

## Pitfalls
- **Title keys must match EXACTLY** between `books-data.js` and `notes-data.js`. Typo in either = no match, no note icon appears.
- **GitHub Pages CDN takes 1-2 minutes** to propagate. User must Cmd+Shift+R.
- **Genre emoji in regex**: JavaScript regex on emoji (surrogate pairs) breaks. Use `genre.split(' ')[0]` to extract emoji, never `/^([📖🧠💻🌍])/`.
- **Data-source issues**: some Excel entries have wrong authors (e.g., "Волшебник изумрудного города" listed under Акунин instead of Волков). Note but don't fix without asking.

## Excel Extraction
When rebuilding from Excel:
```python
import openpyxl
wb = openpyxl.load_workbook("Книги.xlsx")
ws = wb.active
books = []
for row in ws.iter_rows(min_row=2, values_only=True):
    if row[0] and row[1]:
        books.append({"author": str(row[0]).strip(), "title": str(row[1]).strip(), "genre": str(row[2]).strip() if row[2] else ""})
```
