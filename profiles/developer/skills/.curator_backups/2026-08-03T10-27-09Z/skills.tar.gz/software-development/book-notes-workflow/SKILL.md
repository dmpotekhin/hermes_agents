---
name: book-notes-workflow
description: Writing structured book notes for GitHub Pages — format, encoding pitfalls, and CDN quirks
---

# Book Notes Workflow

## Format (user requirement)

Each note is keyed by exact book title (from books-data.js) and contains:

```javascript
"Название Книги": {
  "theses": [
    "Тезис 1: главный герой и его основная задача/проблема",
    "Тезис 2: где и когда происходит действие",
    "Тезис 3: главный конфликт или движущая сила сюжета",
    "Тезис 4: ключевой поворот или неожиданный элемент",
    "Тезис 5: чем всё заканчивается (без спойлеров, только суть)"
  ],
  "takeaway": "2-3 предложения: о чём книга на самом деле, чему учит. Для нон-фикшн — практическая польза."
}
```

For non-fiction: theses focus on concepts, methods, application, key insight, audience/purpose.

## File structure

- `js/notes-data.js` — `const bookNotes = { ... };`
- `js/books.js` — `createBookCard()` renders notes button + expandable panel
- `css/styles.css` — `.book-notes-btn`, `.book-notes-panel`, `.book-notes-theses`, `.book-notes-takeaway`
- `books.html` — includes `<script src="js/notes-data.js"></script>` before `books.js`

## Pitfalls

### Emoji extraction fails with regex

**Symptom:** Icons show as `?` or broken surrogate pairs (`\ud83d`).
**Cause:** Regex `/^([📖🧠💻🌍])\s*/` operates on UTF-16 code units. Emojis like 📖 (U+1F4D6) are surrogate pairs — regex captures only the first code unit.
**Fix:** Use `book.genre.split(' ')[0]` instead.

### Language toggle overwrites dynamic content

**Symptom:** Book count shows empty after page load.
**Cause:** `main.js` `updateTextContent()` replaces innerHTML of elements with `data-lang-*` attributes, overwriting JS-populated spans.
**Fix:** Split label and value into separate elements:
```html
<p><span data-lang-ru="Всего книг:" data-lang-en="Total books:">Всего книг:</span> <span id="total-books">521</span></p>
```

### GitHub Pages CDN stale cache

**Symptom:** Curl shows new file, browser shows old. Different `x-served-by` edge nodes serve different versions.
**Mitigation:** Wait up to 10 minutes (`cache-control: max-age=600`). Use `?nocache` query param in browser.
