---
name: add-book-note
description: "Add a new book to the GitHub Pages library — update Excel, regenerate books-data.js, write note with theses+takeaway, commit & push."
---

# Add Book & Note to GitHub Pages

Use when user says: "добавь книгу", "новая книга", or mentions a new book.

## Workflow

### 1. User adds to Excel manually
User edits `~/Downloads/dmpotekhin.github.io/Книги.xlsx` themselves.
Columns: Author, Title, Genre.
Genre values: `📖 Художественная литература`, `🧠 Саморазвитие / Бизнес / Психология`, `💻 IT / QA / Разработка`, `🌍 История / Страноведение`.

When user says "обнови таблицу" or "я добавил книги" — parse Excel and proceed.

### 2. Parse Excel → rebuild `js/books-data.js`
Run Python script using openpyxl to extract all rows and regenerate the JS array.
- Field mapping: author, title, genre
- Escape quotes and newlines in strings
- Verify: `node -e "new Function(require('fs').readFileSync('js/books-data.js','utf8'))"`

### 3. Write note in `js/notes-data.js`
Key = EXACT `title` from books-data.js. Add to `bookNotes` object before closing `};`.

Format:
```json
{
  "theses": [
    "Тезис 1: главный герой/тема и задача",
    "Тезис 2: место/время или ключевая концепция",
    "Тезис 3: главный конфликт или практическое применение",
    "Тезис 4: поворот/инсайт",
    "Тезис 5: финал/итог"
  ],
  "takeaway": "2-3 предложения: суть книги, чему учит, польза."
}
```

Non-fiction adaptation: тема → концепции → применение → инсайт → итог.

### 4. Commit & Push
```bash
cd ~/Downloads/dmpotekhin.github.io
git add Книги.xlsx js/books-data.js js/notes-data.js
git commit -m "feat: add book — [Title] by [Author]"
git push origin master
```

### 5. Verify
Open `https://dmpotekhin.github.io/books.html`, find new title, click 📝. Cmd+Shift+R if cached.

## Important
- Key must match `title` EXACTLY (punctuation, quotes, years)
- Genre emoji: 📖 🧠 💻 🌍
- Append before `};` in notes-data.js
- Regenerate books-data.js fully from Excel — don't hand-edit