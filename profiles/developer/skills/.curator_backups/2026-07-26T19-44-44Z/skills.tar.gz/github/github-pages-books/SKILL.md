---
name: github-pages-books
description: Manage book collection and notes on dmpotekhin.github.io — add notes, fix rendering, update data from Excel.
---

# GitHub Pages — Book Collection & Notes

Project: `https://github.com/dmpotekhin/dmpotekhin.github.io`
Local: `/Users/dmitrypotekhin/Downloads/dmpotekhin.github.io`
Live: `https://dmpotekhin.github.io/books.html`

## Architecture

```
js/
  books-data.js    — 521 books (author, title, genre) — source: Книги.xlsx
  notes-data.js    — book annotations (theses + takeaway), keyed by title
  books.js         — rendering: cards, search, filters, notes toggle
  main.js          — theme/language toggles
css/styles.css     — all styles including .book-notes-* classes
books.html         — page structure
Книги.xlsx         — master data source (NOT committed)
```

## Book Notes Format

Each entry in `notes-data.js` is keyed by the EXACT book title (as it appears in `books-data.js`):

```javascript
const bookNotes = {
  "Название Книги": {
    "theses": [
      "Тезис 1: главный герой и его задача/проблема",
      "Тезис 2: место и время действия",
      "Тезис 3: главный конфликт или движущая сила сюжета",
      "Тезис 4: ключевой поворот или неожиданный элемент",
      "Тезис 5: чем заканчивается (суть, без спойлеров)"
    ],
    "takeaway": "2-3 предложения: о чём книга на самом деле, чему учит. Для нон-фикшн — практическая польза."
  }
}
```

## Adding Notes

### Adding notes to existing book entries

Use `execute_code` to read `notes-data.js`, find `};` at end, insert new entries before closing:

```python
with open("js/notes-data.js") as f: content = f.read()
end_pos = content.rfind("};")
new_notes = """
  "Book Title": {
    "theses": ["...", "...", "...", "...", "..."],
    "takeaway": "..."
  },
"""
new_content = content[:end_pos] + "," + new_notes + "\n};"
# write back
```

Then update books.js rendering if format changes, then CSS if new classes needed.

### Regenerating books-data.js from Excel

When the Excel file is updated, regenerate `books-data.js`:

```python
import openpyxl, json
wb = openpyxl.load_workbook("Книги.xlsx")
ws = wb.active
books = []
for r in range(2, ws.max_row + 1):
    author = str(ws.cell(r, 1).value).strip()
    title = str(ws.cell(r, 2).value).strip()
    genre = str(ws.cell(r, 3).value).strip() if ws.cell(r, 3).value else ""
    if author and title:
        books.append({"author": author, "title": title, "genre": genre})
# Clean newlines from titles
for b in books:
    b["title"] = b["title"].replace("\n", " ").replace("\r", " ").strip()
# Write as JS const array
```

## Pitfalls

### 1. JavaScript emoji extraction
Do NOT use regex `/[📖🧠💻🌍]/` — it breaks on UTF-16 surrogate pairs (captures half an emoji → renders as "?"). Use `genre.split(' ')[0]` instead.

### 2. Language toggle overwrites dynamic content
Elements with `data-lang-ru`/`data-lang-en` get their `innerHTML` replaced by `main.js`. If a counter `<span id="count">N</span>` lives inside, it gets wiped. Fix: keep label and counter as sibling spans:
```html
<p><span data-lang-ru="Всего:" data-lang-en="Total:">Всего:</span> <span id="count">N</span></p>
```

### 3. CDN propagation
After `git push`, Fastly CDN edge nodes update asynchronously. Different regions get different versions for up to 10 min. Verify with:
```bash
curl -sI https://dmpotekhin.github.io/js/notes-data.js | grep content-length
```

### 4. Subagent delegation model mismatch
The delegation system may pick an unsupported model. If subagents fail with "HTTP 400: supported models are X", write notes directly via `execute_code` — it's faster for known books anyway.

## Notes Rendering

Books with notes get a `.has-notes` class, a `📝 Заметки` button, and a `.book-notes-panel` (hidden by default, expands on click). The panel contains:
- `.book-notes-theses` with `<ol>` (numbered list)
- `.book-notes-takeaway` with `💡 Вывод:` prefix and left-accent border

CSS classes: `book-notes-btn`, `book-notes-panel`, `notes-open`, `book-notes-theses`, `book-notes-takeaway`.

## Verification

After pushing, verify with:
```bash
# Count notes
node -e 'const s=require("fs").readFileSync("js/notes-data.js","utf8");const m=s.match(/const bookNotes = ([\s\S]*);/);const bn=eval("("+m[1]+")");console.log(Object.keys(bn).length);'

# Check CDN propagation
bash ~/.hermes/profiles/developer/skills/github/github-pages/scripts/verify-deploy.sh dmpotekhin dmpotekhin.github.io js/notes-data.js takeaway 5000
```

## Current State (after 2026-07-25 session)

- 300 of 521 books have notes in `notes-data.js`
- 221 books remain without notes
- All entries follow the theses (5 points) + takeaway format
